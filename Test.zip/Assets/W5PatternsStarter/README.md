# W5 Patterns Lab — Starter Kit

A small, self-contained Unity playground for **CAT204TC · Computer Lab 5 (Patterns Implementation)**.
It gives you a working scene plus the non-pattern "infrastructure" — your job in the lab is to build the
three patterns (Singleton, Observer, State) in your own scripts, following the class slides.

**Requirements:** Unity 2022.3 LTS, Universal Render Pipeline (URP) project. No other dependencies —
this kit does not touch anything from earlier weeks.

---

## 1. Import

1. Import `W5PatternsStarter.unitypackage` (double-click it, or **Assets > Import Package > Custom Package**).
   Everything lands inside `Assets/W5PatternsStarter/`.
2. **Register the scenes (required once):** open **File > Build Settings**, then drag **both** scenes from
   `Assets/W5PatternsStarter/Scenes/` into the "Scenes In Build" list:
   - `W5PatternsLab` — the main playground
   - `W5PatternsLab_B` — a small test room (for the DontDestroyOnLoad / duplicate-instance tests)
   Without this step the two portal pads cannot load scenes, and the portal will tell you so on screen.

## 2. Controls

| Key | Action |
|-----|--------|
| W A S D | Move the player |
| SPACE | Melee attack (50 damage in a short radius) |
| F | Travel — stand on a glowing teal portal pad and press F |

## 3. What is in the scene

- **Player** — capsule with `PlayerController`, `PlayerAttack` and `PlayerHealth` (all finished; not part of the patterns).
- **Enemies / Enemy_1, Enemy_2, Enemy_3** — three colored target cubes, spread around the arena.
  Each has two waypoint markers (`Enemy_N_WaypointA/B`) you can use for patrol logic.
- **GameManager** — an empty object. Put *your* `GameManager` script component on it.
- **Portal_To_SceneB** — the teal pad that loads `W5PatternsLab_B` (and a return pad in that scene).
- **GameManager_DuplicateTestSpot** — in `W5PatternsLab_B`; used for the duplicate-instance test.

## 4. The one glue rule — `IDamageable`

The kit cannot know your Enemy class by name, so the player's attack talks to anything that implements
the provided interface `W5Starter.IDamageable`. This is a *deliberate* part of the design:

```csharp
using UnityEngine;
using W5Starter;

public class Enemy : MonoBehaviour, IDamageable
{
    public void TakeDamage(int amount)
    {
        // your HP handling, death, event broadcast, etc.
    }
}
```

As soon as your Enemy implements `IDamageable`, the player's SPACE attack can hurt it. Nothing else to wire.

The starter scripts live in the `W5Starter` namespace so they can never clash with classes in your own project.

## 5. Lab roadmap (mirrors the slides)

**Step 1 — Singleton: `GameManager`** (slide 4)
Create a `GameManager` script with a tight surface (score + level is plenty) and the classic Awake guard:
duplicate check → claim the instance → `DontDestroyOnLoad`.
Verify: press Play, then use the portal to travel to `W5PatternsLab_B` — your manager must survive.
Optional duplicate test: add your `GameManager` component to `GameManager_DuplicateTestSpot` in Scene B,
travel again, and watch the guard destroy the copy (check the Console).

**Step 2 — Observer: enemy death event** (slides 5–6)
Create `Enemy.cs`: HP + `public event Action<Enemy> OnDied`, fired once inside `Die()`; make it implement
`IDamageable` so the player can kill it (50 damage per hit). Then add **at least two subscribers**
(e.g. `ScoreSubscriber` that calls `GameManager.Instance.AddScore(10)`, plus a sound / particle / quest
counter). Subscribe in `OnEnable`, unsubscribe in `OnDisable`. The Enemy must not reference any subscriber.

**Step 3 — State: enemy AI** (slide 7)
Create `EnemyAI.cs` with `enum EnemyState { Patrol, Chase, Attack }` and a switch in `Update`.
Add it to `Enemy_1..3`, wire the Player and each enemy's two patrol waypoints. Print the current state
in the Console (or expose it in the Inspector) so the transitions are visible.

**Step 4 — Wire the attack into the chain** (slide 8)
Make the Attack state reach the player: `player.GetComponent<W5Starter.PlayerHealth>()?.TakeDamage(10)`.
Now the full chain runs: damage in → health counts → death signal out → subscribers react.

**Step 5 — Integration test scene** (slide 9)
Build the score UI (Canvas + TMP text reading `GameManager.Instance.Score`) and confirm everything in
ONE scene: enemy dies → score updates → transitions observable.

**Step 6 — Record + submit**
10-second recording of the full loop + in-class demo. See the class slides for submission details.

## 6. Troubleshooting

| Symptom | Fix |
|---|---|
| Portal says "not in Build Settings" | Add both scenes in File > Build Settings (see step 1 above) |
| Everything renders pink | Your project is not URP; convert materials via Edit > Rendering > Materials, or ask for help |
| TMP text is invisible | Window > TextMeshPro > Import TMP Essential Resources |
| Subscriber misses enemies spawned later | `FindObjectsByType` in `OnEnable` only sees existing objects — subscribe new enemies at spawn time |
| Nothing happens when you press SPACE near an enemy | Your Enemy does not implement `W5Starter.IDamageable` yet |

Everything in your copy of the kit is yours to break, rename and rebuild — the three patterns are the deliverable.
