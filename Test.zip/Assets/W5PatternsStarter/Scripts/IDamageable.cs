namespace W5Starter
{
    /// <summary>
    /// The glue between the starter kit and YOUR code.
    ///
    /// PlayerAttack damages everything in range that implements this interface,
    /// so the kit never needs to know your Enemy class by name.
    ///
    /// To let the player hurt your enemy, add the interface to its declaration:
    ///
    ///     using UnityEngine;
    ///     using W5Starter;
    ///
    ///     public class Enemy : MonoBehaviour, IDamageable
    ///     {
    ///         public void TakeDamage(int amount)
    ///         {
    ///             // your HP handling, death, event broadcast, etc.
    ///         }
    ///     }
    /// </summary>
    public interface IDamageable
    {
        void TakeDamage(int amount);
    }
}
