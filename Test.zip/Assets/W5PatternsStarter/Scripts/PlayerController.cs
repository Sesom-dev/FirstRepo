using UnityEngine;

namespace W5Starter
{
    /// <summary>
    /// Starter-kit player movement — WASD / arrow keys, camera-relative-flat (the camera
    /// looks north, so W walks "up" the screen). The player turns to face the movement
    /// direction.
    ///
    /// This is NOT one of the three patterns. It is just the vehicle you drive while
    /// testing Singleton, Observer and State in your own code.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public class PlayerController : MonoBehaviour
    {
        [SerializeField] private float moveSpeed = 6f;
        [SerializeField] private float turnSpeed = 720f;

        private Rigidbody _rb;
        private Vector3 _moveInput;

        private void Awake() => _rb = GetComponent<Rigidbody>();

        private void Update()
        {
            _moveInput = new Vector3(Input.GetAxisRaw("Horizontal"), 0f, Input.GetAxisRaw("Vertical"));
            if (_moveInput.sqrMagnitude > 1f) _moveInput.Normalize();
        }

        private void FixedUpdate()
        {
            Vector3 velocity = _rb.velocity;
            _rb.velocity = new Vector3(_moveInput.x * moveSpeed, velocity.y, _moveInput.z * moveSpeed);

            if (_moveInput.sqrMagnitude > 0.001f)
            {
                Quaternion target = Quaternion.LookRotation(_moveInput, Vector3.up);
                _rb.MoveRotation(Quaternion.RotateTowards(_rb.rotation, target, turnSpeed * Time.fixedDeltaTime));
            }
        }
    }
}
