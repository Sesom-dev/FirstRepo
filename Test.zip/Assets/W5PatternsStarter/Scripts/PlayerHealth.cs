using UnityEngine;

namespace W5Starter
{
    /// <summary>
    /// Starter-kit player health — a damage target for your EnemyAI's Attack state.
    ///
    /// From your enemy code, damage the player like this:
    ///
    ///     player.GetComponent<W5Starter.PlayerHealth>()?.TakeDamage(10);
    ///
    /// The player flashes red when hit and respawns at the start point when health
    /// reaches zero. This is NOT one of the three patterns — it just gives your enemy
    /// something to hit.
    /// </summary>
    public class PlayerHealth : MonoBehaviour
    {
        [SerializeField] private int maxHealth = 100;
        [SerializeField] private float flashDuration = 0.15f;
        [SerializeField] private Color flashColor = new Color(1f, 0.35f, 0.3f);

        private static readonly int BaseColorId = Shader.PropertyToID("_BaseColor");
        private static readonly int ColorId = Shader.PropertyToID("_Color");

        private Vector3 _spawnPoint;
        private Renderer _renderer;
        private MaterialPropertyBlock _block;
        private Color _baseColor = Color.white;
        private int _colorId;
        private float _flashT;

        public int Health { get; private set; }
        public int MaxHealth => maxHealth;

        private void Awake()
        {
            Health = maxHealth;
            _spawnPoint = transform.position;
            _block = new MaterialPropertyBlock();

            _renderer = GetComponentInChildren<Renderer>();
            if (_renderer != null && _renderer.sharedMaterial != null)
            {
                Material shared = _renderer.sharedMaterial;
                if (shared.HasProperty(BaseColorId)) _colorId = BaseColorId;
                else if (shared.HasProperty(ColorId)) _colorId = ColorId;
                if (_colorId != 0) _baseColor = shared.GetColor(_colorId);
            }
        }

        public void TakeDamage(int amount)
        {
            if (Health <= 0) return;

            Health = Mathf.Max(0, Health - amount);
            _flashT = flashDuration;

            if (Health == 0)
            {
                Debug.Log("[PlayerHealth] Defeated — respawning at the start point.");
                transform.position = _spawnPoint;
                Health = maxHealth;
                _flashT = flashDuration * 3f;
            }
        }

        private void Update()
        {
            if (_flashT <= 0f || _renderer == null || _colorId == 0) return;

            _flashT -= Time.deltaTime;
            _block.SetColor(_colorId, _flashT > 0f ? flashColor : _baseColor);
            _renderer.SetPropertyBlock(_block);
        }
    }
}
