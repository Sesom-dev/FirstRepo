using UnityEngine;
using UnityEngine.SceneManagement;

namespace W5Starter
{
    /// <summary>
    /// Stand on the glowing pad and press F to load the target scene.
    ///
    /// Use it to prove that your Singleton survives a scene load (DontDestroyOnLoad):
    ///   1. Start in W5PatternsLab with your GameManager running.
    ///   2. Walk to the portal and press F.
    ///   3. In W5PatternsLab_B, check that the GameManager is still alive.
    ///
    /// IMPORTANT: SceneManager.LoadScene only works if BOTH scenes are registered in
    /// File > Build Settings > Scenes In Build. If they are not, the portal shows a
    /// reminder on screen instead of loading.
    /// </summary>
    public class ScenePortal : MonoBehaviour
    {
        [SerializeField] private string targetScene = "W5PatternsLab_B";
        [SerializeField] private string prompt = "Press F to travel";

        private bool _playerInRange;
        private string _message;
        private GUIStyle _style;

        /// <summary>Loads the target scene (public so it can be triggered from code/tests).</summary>
        public void Travel()
        {
            if (!Application.CanStreamedLevelBeLoaded(targetScene))
            {
                _message = "Scene '" + targetScene + "' is not in Build Settings. Add BOTH scenes via File > Build Settings.";
                Debug.LogWarning("[ScenePortal] " + _message);
                return;
            }
            SceneManager.LoadScene(targetScene);
        }

        private void Update()
        {
            if (_playerInRange && Input.GetKeyDown(KeyCode.F)) Travel();
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other.GetComponentInParent<PlayerController>() != null) _playerInRange = true;
        }

        private void OnTriggerExit(Collider other)
        {
            if (other.GetComponentInParent<PlayerController>() != null) _playerInRange = false;
        }

        private void OnGUI()
        {
            if (_style == null)
            {
                _style = new GUIStyle(GUI.skin.label)
                {
                    fontSize = Mathf.RoundToInt(16f * Mathf.Max(1f, Screen.height / 900f)),
                    alignment = TextAnchor.MiddleCenter
                };
            }

            if (_playerInRange)
            {
                _style.normal.textColor = Color.white;
                GUI.Label(new Rect(Screen.width * 0.5f - 280f, Screen.height - 70f, 560f, 30f), prompt, _style);
            }

            if (!string.IsNullOrEmpty(_message))
            {
                _style.normal.textColor = new Color(1f, 0.65f, 0.4f);
                GUI.Label(new Rect(Screen.width * 0.5f - 400f, 36f, 800f, 60f), _message, _style);
            }
        }
    }
}
