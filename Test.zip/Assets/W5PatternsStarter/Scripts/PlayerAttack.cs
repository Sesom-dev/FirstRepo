using UnityEngine;

namespace W5Starter
{
    /// <summary>
    /// Starter-kit melee attack — press SPACE to deal 50 damage to everything within
    /// a short radius that implements W5Starter.IDamageable.
    ///
    /// This is the kit's ONE contract with your code: once your Enemy class implements
    /// IDamageable, the player can hurt it. No further wiring needed.
    ///
    /// (The swing animation on the "Weapon" child is cosmetic only.)
    /// </summary>
    public class PlayerAttack : MonoBehaviour
    {
        [SerializeField] private float attackRange = 2.2f;
        [SerializeField] private int damage = 50;
        [SerializeField] private float cooldown = 0.4f;
        [SerializeField] private Transform weapon;

        private float _nextAttackTime;
        private float _swing = -1f;

        private void Update()
        {
            // play the swing animation back to rest
            if (_swing >= 0f)
            {
                _swing -= Time.deltaTime * 4f;
                if (weapon != null) weapon.localRotation = Quaternion.Euler(-85f * Mathf.Clamp01(_swing), 0f, 0f);
            }

            if (Input.GetKeyDown(KeyCode.Space) && Time.time >= _nextAttackTime)
            {
                _nextAttackTime = Time.time + cooldown;
                _swing = 1f;
                Strike();
            }
        }

        private void Strike()
        {
            Collider[] hits = Physics.OverlapSphere(transform.position, attackRange);
            foreach (Collider hit in hits)
            {
                if (hit.transform == transform || hit.transform.IsChildOf(transform)) continue;   // never hit yourself
                IDamageable target = hit.GetComponentInParent<IDamageable>();
                if (target != null) target.TakeDamage(damage);
            }
        }
    }
}
