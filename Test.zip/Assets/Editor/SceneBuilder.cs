using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;

public static class SceneBuilder
{
    private const string ScenePath = "Assets/Scenes/OpenField.unity";
    private const string MaterialsFolder = "Assets/Materials";

    [MenuItem("Tools/Build Open Field Scene")]
    public static void BuildScene()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        // --- Materials ---
        EnsureFolder(MaterialsFolder);
        Material groundMat   = CreateMaterial("Ground",   new Color(0.35f, 0.65f, 0.30f));
        Material buildingMat = CreateMaterial("Building", new Color(0.60f, 0.60f, 0.62f));
        Material playerMat   = CreateMaterial("Player",   new Color(0.20f, 0.45f, 0.90f));

        // --- Lighting ---
        GameObject lightGO = new GameObject("Directional Light");
        Light sun = lightGO.AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.intensity = 1.1f;
        lightGO.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        // --- Large open field (1000m x 1000m, 5x bigger) ---
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";
        ground.transform.localScale = new Vector3(100f, 1f, 100f); // plane is 10x10m at scale 1
        ground.GetComponent<Renderer>().sharedMaterial = groundMat;
        ground.isStatic = true;

        // --- Spawn point at the middle of the map ---
        Vector3 spawnPosition = new Vector3(0f, 1f, 0f);
        GameObject spawnPoint = new GameObject("SpawnPoint");
        spawnPoint.transform.position = spawnPosition;
        spawnPoint.tag = "Respawn"; // Unity's built-in spawn tag

        // --- Player-sized cube at the spawn point ---
        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Cube);
        player.name = "Player";
        player.tag = "Player";
        player.transform.position = spawnPosition;
        player.transform.localScale = new Vector3(1f, 1.8f, 1f);
        player.GetComponent<Renderer>().sharedMaterial = playerMat;
        player.AddComponent<Rigidbody>();
        player.AddComponent<PlayerController>();

        // --- Camera attached to the player ---
        GameObject camGO = new GameObject("PlayerCamera");
        camGO.tag = "MainCamera";
        Camera cam = camGO.AddComponent<Camera>();
        camGO.AddComponent<AudioListener>();
        camGO.transform.SetParent(player.transform);
        camGO.transform.localPosition = new Vector3(0f, 0.8f, -4f);
        camGO.transform.localRotation = Quaternion.identity;
        cam.fieldOfView = 70f;
        cam.farClipPlane = 5000f; // see across the bigger map
        player.GetComponent<PlayerController>().cameraTransform = camGO.transform;

        // --- City grid: blocks of buildings with streets in between ---
        GameObject buildingsRoot = new GameObject("Buildings");
        System.Random rng = new System.Random(12345); // fixed seed = reproducible layout
        int gridHalf = 4;         // 9x9 city blocks
        float blockSpacing = 70f; // distance between block centers (street width = spacing - building width)
        int buildingIndex = 0;

        for (int gx = -gridHalf; gx <= gridHalf; gx++)
        {
            for (int gz = -gridHalf; gz <= gridHalf; gz++)
            {
                // leave the center block open as the spawn plaza
                if (gx == 0 && gz == 0)
                    continue;

                float width  = Mathf.Lerp(20f, 35f, (float)rng.NextDouble());
                float depth  = Mathf.Lerp(20f, 35f, (float)rng.NextDouble());
                float height = Mathf.Lerp(20f, 120f, (float)rng.NextDouble());

                // small jitter so the grid doesn't feel robotic
                float jx = (float)(rng.NextDouble() * 10.0 - 5.0);
                float jz = (float)(rng.NextDouble() * 10.0 - 5.0);

                GameObject building = GameObject.CreatePrimitive(PrimitiveType.Cube);
                building.name = "Building_" + buildingIndex++;
                building.transform.SetParent(buildingsRoot.transform);
                building.transform.position = new Vector3(gx * blockSpacing + jx, height * 0.5f, gz * blockSpacing + jz);
                building.transform.rotation = Quaternion.Euler(0f, (float)(rng.NextDouble() * 10.0 - 5.0), 0f);
                building.transform.localScale = new Vector3(width, height, depth);
                building.GetComponent<Renderer>().sharedMaterial = buildingMat;
                // NOT static: static objects are baked into the occlusion culling
                // data, and destroying them at runtime stalls the game while Unity
                // invalidates the bake.
            }
        }

        // --- NPCs: player-sized cubes wandering the streets ---
        Material npcMat = CreateMaterial("NPC", new Color(0.9f, 0.55f, 0.25f));
        GameObject npcRoot = new GameObject("NPCs");
        int npcCount = 40;

        for (int i = 0; i < npcCount; i++)
        {
            GameObject npc = GameObject.CreatePrimitive(PrimitiveType.Cube);
            npc.name = "NPC_" + i;
            npc.transform.SetParent(npcRoot.transform);

            // spawn on street centers so they never start inside a building
            int lane = rng.Next(-gridHalf, gridHalf); // -4..3 -> street between blocks
            float along = Mathf.Lerp(-280f, 280f, (float)rng.NextDouble());
            bool verticalStreet = rng.NextDouble() < 0.5;
            Vector3 npcPos = verticalStreet
                ? new Vector3(lane * blockSpacing + blockSpacing * 0.5f, 0.9f, along)
                : new Vector3(along, 0.9f, lane * blockSpacing + blockSpacing * 0.5f);

            npc.transform.position = npcPos;
            npc.transform.localScale = new Vector3(1f, 1.8f, 1f); // same size as the player
            npc.GetComponent<Renderer>().sharedMaterial = npcMat;
            npc.AddComponent<Rigidbody>();
            NPCWalker walker = npc.AddComponent<NPCWalker>();
            walker.walkSpeed = Mathf.Lerp(2f, 4f, (float)rng.NextDouble());
        }

        // --- Save ---
        Selection.activeGameObject = player;
        EditorSceneManager.SaveScene(scene, ScenePath);
        AssetDatabase.SaveAssets();
        Debug.Log("Open field scene built and saved to " + ScenePath);
    }

    private static void EnsureFolder(string path)
    {
        if (!AssetDatabase.IsValidFolder(path))
        {
            string parent = System.IO.Path.GetDirectoryName(path).Replace('\\', '/');
            string name = System.IO.Path.GetFileName(path);
            AssetDatabase.CreateFolder(parent, name);
        }
    }

    private static Material CreateMaterial(string name, Color color)
    {
        string path = MaterialsFolder + "/" + name + ".mat";
        Material mat = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (mat == null)
        {
            mat = new Material(Shader.Find("Standard"));
            AssetDatabase.CreateAsset(mat, path);
        }
        mat.color = color;
        EditorUtility.SetDirty(mat);
        return mat;
    }
}
