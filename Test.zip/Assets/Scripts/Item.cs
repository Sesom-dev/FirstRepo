using UnityEngine;

[CreateAssetMenu(fileName = "New Item", menuName = "Inventory/Item")]
public class Item : ScriptableObject
{
    public string ID, displayName, description;
    public int value, maxStack = 1;
    public Sprite icon;
    public bool isStackable => maxStack > 1;
    public enum Category { Weapon, Consumable, Material, Key, Quest }
    public Category category;
}
