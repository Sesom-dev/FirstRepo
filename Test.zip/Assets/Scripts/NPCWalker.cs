using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class NPCWalker : MonoBehaviour
{
    public float walkSpeed = 3f, turnSpeed = 5f, wanderRadius = 300f;
    private Rigidbody rb;
    private Vector3 target;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.isKinematic = true;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        PickNewTarget();
    }

    void FixedUpdate()
    {
        Vector3 to = target - transform.position;
        to.y = 0f;
        if (to.magnitude < 2f || Physics.Raycast(transform.position, to.normalized, 3f)) { PickNewTarget(); return; }
        Vector3 dir = to.normalized;
        rb.MoveRotation(Quaternion.Slerp(rb.rotation, Quaternion.LookRotation(dir), turnSpeed * Time.fixedDeltaTime));
        rb.MovePosition(rb.position + dir * walkSpeed * Time.fixedDeltaTime);
    }

    void PickNewTarget()
    {
        Vector2 c = Random.insideUnitCircle * wanderRadius;
        target = new Vector3(c.x, transform.position.y, c.y);
    }
}
