using UnityEngine;
using System.Collections;

public class DebrisPickup : MonoBehaviour
{
    public Item item;
    public float pickupRadius = 2.5f;
    public float lifetime = 10f;

    // Static cached references — no FindObjectOfType calls ever
    public static System.Action<GameObject> releaseAction;
    private static Transform player;
    private static Inventory inventory;

    private Rigidbody rb;
    private float activateTime;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        if (rb == null) rb = gameObject.AddComponent<Rigidbody>();
        if (player == null && PlayerController.Instance) player = PlayerController.Instance.transform;
        if (inventory == null && InventoryUI.Instance) inventory = InventoryUI.Instance.inventory;
    }

    void OnEnable()
    {
        activateTime = Time.time;
        if (player == null && PlayerController.Instance) player = PlayerController.Instance.transform;
        StartCoroutine(AutoRelease());
    }

    void Update()
    {
        if (item == null) return;

        // Skip expensive distance check while still bouncing — debris settles quickly
        if (rb != null && rb.velocity.sqrMagnitude > 1f) return;

        // Only check pickup if within range
        if (player != null && inventory != null && Vector3.Distance(transform.position, player.position) <= pickupRadius)
        {
            if (inventory.TryAdd(item)) InventoryUI.PickedUpCount++;
            Release();
        }
    }

    IEnumerator AutoRelease()
    {
        yield return new WaitForSeconds(lifetime);
        if (gameObject.activeSelf && rb != null && rb.velocity.sqrMagnitude < 0.1f)
        {
            // Debris settled, release it
            Release();
        }
        else if (gameObject.activeSelf)
        {
            // Still bouncing — check again soon
            yield return new WaitForSeconds(2f);
            if (gameObject.activeSelf) Release();
        }
    }

    void Release()
    {
        if (releaseAction != null) releaseAction(gameObject);
        else gameObject.SetActive(false);
    }
}
