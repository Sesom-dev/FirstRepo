using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;
using System.Collections.Generic;

[RequireComponent(typeof(Rigidbody))]
public class PlayerController : MonoBehaviour
{
    public static PlayerController Instance { get; private set; }

    [Header("Ground Movement")]
    public float moveSpeed = 6f, accelerationTime = 0.12f, jumpForce = 8f, fallGravityMultiplier = 2.5f;
    [Header("Camera")]
    public Transform cameraTransform;
    public float mouseSensitivity = 3f, pitchMin = -80f, pitchMax = 80f;
    public Vector3 groundCamOffset = new Vector3(0f, 0.8f, -4f), flightCamOffset = new Vector3(0f, 1.5f, -7f);
    [Header("Flight")]
    public float launchSpeed = 55f, flightTargetHeight = 80f, descendSpeed = 15f;
    public float maxFlySpeed = 50f, flyAcceleration = 30f, boostSpeed = 130f, boostChangeRate = 120f;
    public float barrelRollDuration = 0.6f, bankAmount = 0.4f, maxBankAngle = 45f, hoverBobSpeed = 2f, hoverBobAmount = 0.5f;
    [Header("Destruction")]
    public float destructionMinSpeed = 80f, explosionForce = 1500f, explosionRadius = 25f, explosionUpwards = 3f;
    public int debrisPieces = 8, buildingsPerLevel = 10, debrisPoolSize = 50;
    [Header("Feel")]
    public float fovIncrease = 25f, maxBoostShake = 0.3f, nearMissRadius = 6f, nearMissCooldown = 1.5f;

    private int destructionCount, level = 1, nearMissCount;
    private float levelUpTime = -10f, lastNearMissTime = -10f;
    private Rigidbody rb;
    private bool isGrounded, isFlying, isDescending, isRolling, isLaunching, powerBoostReceived;
    private float yaw, pitch, lastYaw, bank, shakeKick, roll, flySpeed, currentFlySpeed, airborneTime, hoverTime, lastDemolishTime = -10f;
    private float baseFOV;
    private Vector3 camVelocity, moveVelocity;
    private ParticleSystem burstFX;
    private TrailRenderer contrail;
    private Material particleMat;
    private static Item scrapItem;

    // debris pool
    private Queue<GameObject> debrisPool;
    private GameObject debrisPoolParent;
    private Collider playerCollider;

    void Awake()
    {
        Instance = this;
        // Ensure SettingsUI exists on this object (persists across scene rebuilds)
        if (GetComponent<SettingsUI>() == null) gameObject.AddComponent<SettingsUI>();

        rb = GetComponent<Rigidbody>();
        rb.mass = 5f; rb.freezeRotation = true;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        playerCollider = GetComponent<Collider>() ?? gameObject.AddComponent<BoxCollider>();
        if (cameraTransform == null && Camera.main) cameraTransform = Camera.main.transform;
        if (cameraTransform)
        {
            cameraTransform.SetParent(null);
            var cam = cameraTransform.GetComponent<Camera>();
            if (cam) baseFOV = cam.fieldOfView;
        }
        yaw = transform.eulerAngles.y; lastYaw = yaw;
        particleMat = CreateParticleMaterial();
        CreateAirEffects();

        // Build debris pool (cheaper Rigidbody settings for pooled objects)
        debrisPool = new Queue<GameObject>();
        debrisPoolParent = new GameObject("DebrisPool");
        debrisPoolParent.transform.SetParent(transform, false);
        for (int i = 0; i < debrisPoolSize; i++)
        {
            var d = GameObject.CreatePrimitive(PrimitiveType.Cube);
            d.name = "Debris";
            d.SetActive(false);
            d.transform.SetParent(debrisPoolParent.transform, false);
            var drb = d.AddComponent<Rigidbody>();
            drb.mass = 5f;
            drb.interpolation = RigidbodyInterpolation.None;
            drb.collisionDetectionMode = CollisionDetectionMode.Discrete;
            Physics.IgnoreCollision(d.GetComponent<Collider>(), playerCollider);
            d.AddComponent<DebrisPickup>();
            debrisPool.Enqueue(d);
        }
        // Let DebrisPickup return debris to this pool
        DebrisPickup.releaseAction = ReleaseDebris;

        SetCursorLocked(true);
    }

    void Update()
    {
        if (!InventoryUI.IsOpen && Cursor.lockState == CursorLockMode.Locked)
        {
            yaw += Input.GetAxis("Mouse X") * mouseSensitivity;
            pitch = Mathf.Clamp(pitch - Input.GetAxis("Mouse Y") * mouseSensitivity, pitchMin, pitchMax);
        }
        else if (Input.GetMouseButtonDown(0) && !EventSystem.current.IsPointerOverGameObject()) SetCursorLocked(true);
        if (InventoryUI.IsOpen) return;

        // receive the permanent power boost with shift once level 3 is unlocked
        if (level >= 3 && !powerBoostReceived && (Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift)))
            ReceivePowerBoost();

        if (isFlying)
        {
            if (Input.GetKey(KeyCode.W)) flySpeed += flyAcceleration * Time.deltaTime;
            if (Input.GetKey(KeyCode.S)) flySpeed -= flyAcceleration * Time.deltaTime;
            flySpeed = Mathf.Clamp(flySpeed, 0f, maxFlySpeed);
            if (Input.GetKeyDown(KeyCode.A)) StartCoroutine(BarrelRoll(1f));
            if (Input.GetKeyDown(KeyCode.D)) StartCoroutine(BarrelRoll(-1f));
            if (Input.GetKeyDown(KeyCode.F)) BeginDescent();
        }
        else if (!isDescending)
        {
            if (isGrounded && Input.GetKeyDown(KeyCode.Space))
            {
                var vel = rb.velocity; vel.y = 0f; rb.velocity = vel;
                rb.AddForce(Vector3.up * jumpForce, ForceMode.VelocityChange);
                isGrounded = false;
            }
            if (isGrounded && Input.GetKeyDown(KeyCode.F)) StartCoroutine(LaunchRoutine());
        }
    }

    void FixedUpdate()
    {
        if (isFlying)
        {
            if (!isLaunching)
            {
                bool boosting = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
                float targetSpeed = boosting ? boostSpeed : flySpeed;
                currentFlySpeed = Mathf.MoveTowards(currentFlySpeed, targetSpeed, boostChangeRate * Time.fixedDeltaTime);
                var flightRot = Quaternion.Euler(pitch, yaw, 0f);
                rb.velocity = flightRot * Vector3.forward * currentFlySpeed;
                rb.angularVelocity = Vector3.zero;
                float yawRate = (yaw - lastYaw) / Time.fixedDeltaTime;
                float targetBank = Mathf.Clamp(-yawRate * bankAmount, -maxBankAngle, maxBankAngle);
                bank = Mathf.Lerp(bank, targetBank, 5f * Time.fixedDeltaTime);
                rb.MoveRotation(flightRot * Quaternion.Euler(0f, 0f, bank + roll));
                if (currentFlySpeed < 1f)
                {
                    hoverTime += Time.fixedDeltaTime;
                    var vel = rb.velocity;
                    vel.y = Mathf.Sin(hoverTime * hoverBobSpeed) * hoverBobAmount;
                    rb.velocity = vel;
                }
                else hoverTime = 0f;

                // speed-proportional shake while boosting (stacks with demolition shake)
                if (boosting && currentFlySpeed > 1f)
                    shakeKick = Mathf.Max(shakeKick, Mathf.InverseLerp(0f, boostSpeed, currentFlySpeed) * maxBoostShake);
            }
            // contrail emits while flying fast
            if (contrail) contrail.emitting = currentFlySpeed > 5f;

            // near-miss: flying close to a building grants a bonus (with cooldown)
            if (currentFlySpeed > 10f && Time.time - lastNearMissTime > nearMissCooldown)
            {
                var hits = Physics.OverlapSphere(transform.position, nearMissRadius);
                foreach (var h in hits)
                    if (h.gameObject.name.StartsWith("Building"))
                    {
                        nearMissCount++;
                        lastNearMissTime = Time.time;
                        shakeKick = Mathf.Max(shakeKick, 0.4f);
                        break;
                    }
            }

            if (isGrounded)
            {
                if (airborneTime > 0.3f && Time.time - lastDemolishTime > 0.15f) ExitFlight();
            }
            else airborneTime += Time.fixedDeltaTime;
        }
        else if (isDescending)
        {
            rb.velocity = Vector3.down * descendSpeed;
            rb.angularVelocity = Vector3.zero;
            bank = Mathf.Lerp(bank, 0f, 5f * Time.fixedDeltaTime);
            rb.MoveRotation(Quaternion.Slerp(rb.rotation, Quaternion.Euler(0f, yaw, 0f), 5f * Time.fixedDeltaTime));
            if (isGrounded) ExitFlight();
        }
        else
        {
            float h = InventoryUI.IsOpen ? 0f : Input.GetAxisRaw("Horizontal");
            float v = InventoryUI.IsOpen ? 0f : Input.GetAxisRaw("Vertical");
            var dir = Quaternion.Euler(0f, yaw, 0f) * (Vector3.forward * v + Vector3.right * h);
            if (dir.sqrMagnitude > 1f) dir.Normalize();
            var horizontal = Vector3.SmoothDamp(new Vector3(rb.velocity.x, 0f, rb.velocity.z), dir * moveSpeed, ref moveVelocity, accelerationTime);
            rb.velocity = new Vector3(horizontal.x, rb.velocity.y, horizontal.z);
            if (rb.velocity.y < 0f) rb.AddForce(Physics.gravity * (fallGravityMultiplier - 1f), ForceMode.Acceleration);
            rb.MoveRotation(Quaternion.Slerp(rb.rotation, Quaternion.identity, 8f * Time.fixedDeltaTime));
        }
        lastYaw = yaw;
    }

    void LateUpdate()
    {
        if (cameraTransform == null) return;
        var camRot = Quaternion.Euler(pitch, yaw, 0f);
        var desiredPos = transform.position + camRot * (isFlying ? flightCamOffset : groundCamOffset);
        cameraTransform.position = Vector3.SmoothDamp(cameraTransform.position, desiredPos, ref camVelocity, 0.05f);
        if (shakeKick > 0f) cameraTransform.position += Random.insideUnitSphere * shakeKick;
        shakeKick = Mathf.MoveTowards(shakeKick, 0f, 2f * Time.deltaTime);
        cameraTransform.rotation = camRot;

        // speed-dependent FOV: widens as the player flies faster
        var cam = cameraTransform.GetComponent<Camera>();
        if (cam && baseFOV > 0f)
        {
            float t = isFlying ? Mathf.Clamp01(currentFlySpeed / boostSpeed) : 0f;
            cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, baseFOV + t * fovIncrease, 5f * Time.deltaTime);
        }
    }

    IEnumerator LaunchRoutine()
    {
        burstFX.Play();
        isFlying = true; isLaunching = true;
        rb.useGravity = false; rb.freezeRotation = false;
        airborneTime = 0f; hoverTime = 0f; flySpeed = 0f; currentFlySpeed = 0f;
        float targetY = transform.position.y + flightTargetHeight;
        while (isLaunching && transform.position.y < targetY)
        {
            rb.velocity = new Vector3(0f, launchSpeed, 0f);
            yield return new WaitForFixedUpdate();
        }
        if (isLaunching) { rb.velocity = Vector3.zero; isLaunching = false; }
    }

    void BeginDescent() { isLaunching = false; isFlying = false; isDescending = true; roll = 0f; }

    IEnumerator BarrelRoll(float direction)
    {
        if (isRolling) yield break;
        isRolling = true;
        float start = roll, end = start + 360f * direction, elapsed = 0f;
        while (elapsed < barrelRollDuration)
        {
            elapsed += Time.deltaTime;
            roll = Mathf.Lerp(start, end, Mathf.SmoothStep(0f, 1f, elapsed / barrelRollDuration));
            yield return null;
        }
        roll = start; isRolling = false;
    }

    void ExitFlight()
    {
        isLaunching = false; isFlying = false; isDescending = false;
        roll = 0f; bank = 0f; flySpeed = 0f; currentFlySpeed = 0f;
        if (contrail) contrail.emitting = false;
        rb.useGravity = true; rb.freezeRotation = true;
    }

    // Grants the permanent level-3 power boost: 2x flight speed + crazier camera zoom.
    void ReceivePowerBoost()
    {
        powerBoostReceived = true;
        boostSpeed *= 2f;
        flightCamOffset *= 2f;
        baseFOV = Mathf.Min(baseFOV * 1.4f, 110f);
    }

    void OnCollisionEnter(Collision collision)
    {
        if (isFlying && currentFlySpeed >= destructionMinSpeed && collision.gameObject.name.StartsWith("Building"))
            Demolish(collision.gameObject, collision.GetContact(0).point);
    }

    void Demolish(GameObject building, Vector3 hitPoint)
    {
        var bounds = building.GetComponent<Collider>().bounds;
        var mat = building.GetComponent<Renderer>().sharedMaterial;
        Destroy(building);
        var scrap = GetScrapItem();

        // Spawn debris from pool
        var rigids = new List<Rigidbody>(debrisPieces);
        for (int i = 0; i < debrisPieces; i++)
        {
            var d = GetDebris();
            d.SetActive(true);
            d.transform.position = bounds.center + new Vector3(
                Random.Range(-bounds.extents.x, bounds.extents.x),
                Random.Range(-bounds.extents.y, bounds.extents.y),
                Random.Range(-bounds.extents.z, bounds.extents.z));
            d.transform.rotation = Random.rotation;
            d.transform.localScale = new Vector3(Random.Range(2f, 6f), Random.Range(2f, 6f), Random.Range(2f, 6f));
            d.GetComponent<Renderer>().sharedMaterial = mat;
            var drb = d.GetComponent<Rigidbody>();
            if (drb == null) drb = d.AddComponent<Rigidbody>();
            drb.velocity = Vector3.zero; drb.angularVelocity = Vector3.zero;
            d.GetComponent<DebrisPickup>().item = scrap;
            rigids.Add(drb);
        }
        // Single explosion applied once to all Rigidbodies
        foreach (var r in rigids) r.AddExplosionForce(explosionForce, hitPoint, explosionRadius, explosionUpwards);

        // Decal pile: one static rubble cube at the building footprint
        var pile = GameObject.CreatePrimitive(PrimitiveType.Cube);
        pile.name = "DebrisPile";
        pile.transform.position = bounds.center - Vector3.up * bounds.extents.y * 0.6f;
        pile.transform.localScale = new Vector3(bounds.size.x * 0.9f, bounds.size.y * 0.25f, bounds.size.z * 0.9f);
        pile.GetComponent<Renderer>().sharedMaterial = mat;
        var pileRb = pile.AddComponent<Rigidbody>(); pileRb.isKinematic = true;  // static, won't add to physics
        Destroy(pile, 15f);

        burstFX.Play();
        shakeKick = 1f;
        lastDemolishTime = Time.time;
        if (++destructionCount >= buildingsPerLevel) { destructionCount = 0; level++; levelUpTime = Time.time; }
    }

    GameObject GetDebris()
    {
        if (debrisPool.Count == 0)
        {
            // auto-grow pool
            for (int i = 0; i < 10; i++)
            {
                var d = GameObject.CreatePrimitive(PrimitiveType.Cube);
                d.name = "Debris"; d.SetActive(false);
                d.transform.SetParent(debrisPoolParent.transform, false);
                var drb = d.AddComponent<Rigidbody>();   // ← was GetComponent, CreatePrimitive doesn't add Rigidbody
                drb.mass = 5f; drb.interpolation = RigidbodyInterpolation.None;
                drb.collisionDetectionMode = CollisionDetectionMode.Discrete;
                Physics.IgnoreCollision(d.GetComponent<Collider>(), playerCollider);
                d.AddComponent<DebrisPickup>();
                debrisPool.Enqueue(d);
            }
        }
        return debrisPool.Dequeue();
    }

    public void ReleaseDebris(GameObject d)
    {
        if (d == null) return;
        d.SetActive(false);
        if (debrisPoolParent) d.transform.SetParent(debrisPoolParent.transform, false);
        if (d.TryGetComponent<Rigidbody>(out var drb)) { drb.velocity = Vector3.zero; drb.angularVelocity = Vector3.zero; }
        if (d.TryGetComponent<DebrisPickup>(out var pk)) pk.item = null;
        debrisPool.Enqueue(d);
    }

    void OnCollisionStay(Collision collision)
    {
        isGrounded = false;
        foreach (var contact in collision.contacts)
            if (Vector3.Dot(contact.normal, Vector3.up) > 0.5f) { isGrounded = true; return; }
    }

    void OnCollisionExit(Collision collision) { isGrounded = false; }

    void SetCursorLocked(bool locked) { Cursor.lockState = locked ? CursorLockMode.Locked : CursorLockMode.None; Cursor.visible = !locked; }

    Item GetScrapItem()
    {
        if (scrapItem) return scrapItem;
        scrapItem = ScriptableObject.CreateInstance<Item>();
        scrapItem.ID = "scrap"; scrapItem.displayName = "Scrap";
        scrapItem.description = "Chunk of a destroyed building.";
        scrapItem.maxStack = 99; scrapItem.category = Item.Category.Material;
        const int size = 32;
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                float t = (x + y) / (size * 2f);
                var c = Color.Lerp(new Color(0.55f, 0.5f, 0.45f), new Color(0.85f, 0.75f, 0.6f), t);
                if (Mathf.Min(Mathf.Min(x, y), Mathf.Min(size - 1 - x, size - 1 - y)) < 2f) c *= 0.6f;
                tex.SetPixel(x, y, c);
            }
        tex.Apply();
        scrapItem.icon = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f);
        return scrapItem;
    }

    void OnGUI()
    {
        float barWidth = 220f, barHeight = 24f, margin = 16f;
        var barRect = new Rect(Screen.width - barWidth - margin, margin + 24f, barWidth, barHeight);
        float pulseElapsed = Time.time - levelUpTime;
        float pulse = pulseElapsed < 0.6f ? 1f + Mathf.Sin(pulseElapsed / 0.6f * Mathf.PI) * 0.25f : 1f;
        var center = barRect.center;
        GUI.matrix = Matrix4x4.TRS(center, Quaternion.identity, new Vector3(pulse, pulse, 1f)) * Matrix4x4.TRS(-center, Quaternion.identity, Vector3.one);
        GUI.color = new Color(0f, 0f, 0f, 0.6f);
        GUI.DrawTexture(barRect, Texture2D.whiteTexture);
        float fill = (float)destructionCount / buildingsPerLevel;
        var fillRect = new Rect(barRect.x + 2f, barRect.y + 2f, (barRect.width - 4f) * fill, barRect.height - 4f);
        GUI.color = pulseElapsed < 0.6f ? Color.Lerp(new Color(1f, 0.6f, 0.1f), Color.yellow, Mathf.PingPong(pulseElapsed * 6f, 1f)) : new Color(1f, 0.6f, 0.1f);
        GUI.DrawTexture(fillRect, Texture2D.whiteTexture);
        GUI.color = Color.white;
        var labelStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold };
        GUI.Label(barRect, destructionCount + " / " + buildingsPerLevel, labelStyle);
        GUI.matrix = Matrix4x4.identity;
        var levelStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleRight, fontStyle = FontStyle.Bold, fontSize = 18 };
        levelStyle.normal.textColor = pulseElapsed < 0.6f ? Color.yellow : Color.white;
        GUI.Label(new Rect(Screen.width - barWidth - margin, margin, barWidth, 22f), pulseElapsed < 0.6f ? "LEVEL UP! Level " + level : "Level " + level, levelStyle);

        // near-miss counter (bottom-left)
        if (nearMissCount > 0)
        {
            var nmStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleLeft, fontStyle = FontStyle.Bold, fontSize = 16 };
            nmStyle.normal.textColor = new Color(1f, 0.85f, 0.4f);
            GUI.Label(new Rect(margin, Screen.height - margin - 24f, 200f, 24f), "Near Misses: " + nearMissCount, nmStyle);
        }

        // power-up prompt (only while not yet received)
        if (level >= 3 && !powerBoostReceived)
        {
            var puStyle = new GUIStyle(GUI.skin.label) { fontSize = 28, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            puStyle.normal.textColor = Color.yellow;
            GUI.Label(new Rect(0, Screen.height * 0.4f, Screen.width, 60f), "Power Up Available!\nClick Shift To Receive!", puStyle);
        }
    }

    Material CreateParticleMaterial()
    {
        const int size = 64;
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        tex.wrapMode = TextureWrapMode.Clamp;
        var center = new Vector2(size * 0.5f, size * 0.5f);
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                float d = Vector2.Distance(new Vector2(x, y), center) / (size * 0.5f);
                float a = Mathf.Clamp01(1f - d); a *= a;
                tex.SetPixel(x, y, new Color(1f, 1f, 1f, a));
            }
        tex.Apply();
        var mat = new Material(Shader.Find("Legacy Shaders/Particles/Alpha Blended"));
        mat.mainTexture = tex;
        return mat;
    }

    void CreateAirEffects()
    {
        var burstGO = new GameObject("AirBurstFX");
        burstGO.transform.SetParent(transform, false);
        burstGO.transform.localPosition = new Vector3(0f, -0.9f, 0f);
        burstGO.transform.localRotation = Quaternion.Euler(-90f, 0f, 0f);
        burstFX = burstGO.AddComponent<ParticleSystem>();
        burstFX.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        burstGO.GetComponent<ParticleSystemRenderer>().material = particleMat;
        var m = burstFX.main;
        m.loop = false; m.playOnAwake = false; m.duration = 0.5f; m.startLifetime = 0.7f;
        m.startSpeed = 14f; m.startSize = 0.4f; m.startColor = new Color(0.9f, 0.95f, 1f, 0.9f); m.gravityModifier = -0.5f;
        var e = burstFX.emission;
        e.rateOverTime = 0f; e.SetBursts(new[] { new ParticleSystem.Burst(0f, 60) });
        var s = burstFX.shape;
        s.shapeType = ParticleSystemShapeType.Cone; s.angle = 25f; s.radius = 0.5f;
        burstFX.Stop();

        // contrail: soft glowing trail that follows the player while flying fast
        var trailGO = new GameObject("Contrail");
        trailGO.transform.SetParent(transform, false);
        contrail = trailGO.AddComponent<TrailRenderer>();
        contrail.material = particleMat;
        contrail.startWidth = 0.6f; contrail.endWidth = 0f;
        contrail.time = 0.4f;
        contrail.startColor = new Color(0.7f, 0.85f, 1f, 0.8f);
        contrail.endColor = new Color(0.7f, 0.85f, 1f, 0f);
        contrail.emitting = false;
    }
}
