using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;

public class InventoryUI : MonoBehaviour
{
    public Inventory inventory;
    public KeyCode toggleKey = KeyCode.G;
    public static InventoryUI Instance { get; private set; }
    public static bool IsOpen { get; private set; }
    public static int PickedUpCount { get; set; }

    private GameObject panel;
    private Transform grids;
    private readonly List<InventorySlotUI> slots = new List<InventorySlotUI>();
    private TMP_Text pickedUpLabel;

    void Awake()
    {
        Instance = this;
        toggleKey = KeyCode.G; // force G regardless of old serialized inspector value
        var canvas = GameObject.Find("Canvas");
        if (canvas == null) { Debug.LogError("InventoryUI: no Canvas named 'Canvas' found."); return; }

        // Make sure drag input works: an EventSystem and a GraphicRaycaster are required.
        if (FindObjectOfType<EventSystem>() == null)
        {
            var es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
            es.AddComponent<StandaloneInputModule>();
        }
        if (canvas.GetComponent<GraphicRaycaster>() == null)
            canvas.AddComponent<GraphicRaycaster>();

        panel = canvas.transform.GetChild(0).gameObject;
        grids = panel.transform.Find("Grids");
        if (inventory == null) inventory = GetComponent<Inventory>() ?? gameObject.AddComponent<Inventory>();
        for (int i = 0; i < grids.childCount; i++)
        {
            var slotGO = grids.GetChild(i).gameObject;
            var slotUI = slotGO.GetComponent<InventorySlotUI>() ?? slotGO.AddComponent<InventorySlotUI>();
            slotUI.index = i; slots.Add(slotUI);
        }
        inventory.OnChanged += Refresh;
        panel.SetActive(false);
        CreatePickedUpLabel();
        Refresh();
    }

    void CreatePickedUpLabel()
    {
        var labelGO = new GameObject("PickedUpCount", typeof(RectTransform), typeof(TextMeshProUGUI));
        labelGO.transform.SetParent(transform, false);
        var rt = labelGO.GetComponent<RectTransform>();
        rt.anchorMin = new Vector2(0.5f, 1f); rt.anchorMax = new Vector2(0.5f, 1f);
        rt.pivot = new Vector2(0.5f, 1f); rt.anchoredPosition = new Vector2(0f, -12f);
        rt.sizeDelta = new Vector2(400f, 40f);
        pickedUpLabel = labelGO.GetComponent<TextMeshProUGUI>();
        pickedUpLabel.fontSize = 26;
        pickedUpLabel.alignment = TextAlignmentOptions.Top | TextAlignmentOptions.Center;
        pickedUpLabel.raycastTarget = false;
        pickedUpLabel.color = new Color(1f, 0.85f, 0.4f);
        UpdatePickedUpLabel();
    }

    void UpdatePickedUpLabel() { if (pickedUpLabel) pickedUpLabel.text = "Scrap Collected: " + PickedUpCount; }

    void Update()
    {
        if (pickedUpLabel && pickedUpLabel.text != "Scrap Collected: " + PickedUpCount) UpdatePickedUpLabel();
        if (Input.GetKeyDown(KeyCode.G)) Toggle();
    }

    void Toggle()
    {
        bool open = !panel.activeSelf;
        panel.SetActive(open); IsOpen = open;
        Cursor.lockState = open ? CursorLockMode.None : CursorLockMode.Locked;
        Cursor.visible = open;
        Refresh();
    }

    void Refresh()
    {
        for (int i = 0; i < slots.Count; i++)
            slots[i].SetSlot(i < inventory.Slots.Count ? inventory.Slots[i] : null);
    }

    public bool HasItem(int i) => i < inventory.Slots.Count && !inventory.Slots[i].IsEmpty;

    public void MoveSlot(int from, int to) => inventory.Move(from, to);

    // Remove one item from a slot and spawn it as a pickup in front of the camera.
    public void DropItem(int index)
    {
        if (!HasItem(index)) return;
        var slot = inventory.Slots[index];
        var item = slot.Item;
        inventory.RemoveAt(index, 1);

        if (Camera.main == null) return;
        var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = "Dropped_" + item.displayName;
        go.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 3f;
        go.transform.localScale = Vector3.one * 0.5f;
        go.AddComponent<Rigidbody>();
        go.AddComponent<DebrisPickup>().item = item;
    }
}
