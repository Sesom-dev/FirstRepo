using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;

public class InventorySlotUI : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler,
    IBeginDragHandler, IDragHandler, IEndDragHandler, IDropHandler
{
    public int index;
    private Image icon;
    private TMP_Text qtyText;
    private Vector3 baseScale = Vector3.one;

    // shared drag state across all slots
    private static InventorySlotUI dragging;
    private static GameObject dragIcon;
    private static Canvas canvas;
    private static bool dropAccepted;

    void Awake()
    {
        var iconGO = new GameObject("Icon", typeof(RectTransform), typeof(Image));
        iconGO.transform.SetParent(transform, false);
        var irt = iconGO.GetComponent<RectTransform>();
        irt.anchorMin = Vector2.zero; irt.anchorMax = Vector2.one;
        irt.offsetMin = new Vector2(6, 6); irt.offsetMax = new Vector2(-6, -6);
        icon = iconGO.GetComponent<Image>();
        icon.raycastTarget = false; icon.enabled = false;

        var qtyGO = new GameObject("Qty", typeof(RectTransform), typeof(TextMeshProUGUI));
        qtyGO.transform.SetParent(transform, false);
        var qrt = qtyGO.GetComponent<RectTransform>();
        qrt.anchorMin = new Vector2(1f, 0f); qrt.anchorMax = new Vector2(1f, 0f);
        qrt.pivot = new Vector2(1f, 0f); qrt.anchoredPosition = new Vector2(-4f, 4f);
        qrt.sizeDelta = new Vector2(60f, 24f);
        qtyText = qtyGO.GetComponent<TextMeshProUGUI>();
        qtyText.fontSize = 18;
        qtyText.alignment = TextAlignmentOptions.Bottom | TextAlignmentOptions.Right;
        qtyText.raycastTarget = false; qtyText.text = "";
    }

    public void SetSlot(InventorySlot slot)
    {
        if (slot == null || slot.IsEmpty) { icon.enabled = false; qtyText.text = ""; }
        else { icon.enabled = true; icon.sprite = slot.Item.icon; qtyText.text = slot.quantity > 1 ? slot.quantity.ToString() : ""; }
    }

    public void OnPointerEnter(PointerEventData e) { baseScale = transform.localScale; transform.localScale = Vector3.one * 1.12f; }
    public void OnPointerExit(PointerEventData e) { transform.localScale = baseScale; }

    public void OnBeginDrag(PointerEventData e)
    {
        if (InventoryUI.Instance == null || !InventoryUI.Instance.HasItem(index)) return;
        dragging = this;
        dropAccepted = false;
        if (canvas == null) canvas = GetComponentInParent<Canvas>();
        dragIcon = new GameObject("DragIcon", typeof(RectTransform), typeof(Image));
        var img = dragIcon.GetComponent<Image>();
        img.sprite = icon.sprite;
        img.raycastTarget = false;
        dragIcon.transform.SetParent(canvas.transform, false);
        dragIcon.transform.SetAsLastSibling();
        dragIcon.GetComponent<RectTransform>().sizeDelta = icon.rectTransform.rect.size;
    }

    public void OnDrag(PointerEventData e) { if (dragIcon) dragIcon.transform.position = e.position; }

    public void OnEndDrag(PointerEventData e)
    {
        if (dragIcon) Destroy(dragIcon);
        dragIcon = null;
        // If no slot accepted the drop, drop the item on the ground.
        if (!dropAccepted && dragging == this)
            InventoryUI.Instance.DropItem(index);
        dragging = null;
    }

    public void OnDrop(PointerEventData e)
    {
        if (dragging == null || dragging == this) return;
        InventoryUI.Instance.MoveSlot(dragging.index, index);
        dropAccepted = true;
    }
}
