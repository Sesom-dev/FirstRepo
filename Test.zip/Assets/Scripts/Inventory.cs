using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class InventorySlot
{
    public Item Item;
    public int quantity;
    public bool IsEmpty => Item == null || quantity <= 0;
    public bool CanAccept(Item other) => Item != null && Item.ID == other.ID && quantity < Item.maxStack;
}

public class Inventory : MonoBehaviour
{
    [SerializeField] private int slotCount = 16;
    public List<InventorySlot> Slots { get; private set; }
    public event Action OnChanged;

    void Awake()
    {
        Slots = new List<InventorySlot>(slotCount);
        for (int i = 0; i < slotCount; i++) Slots.Add(new InventorySlot());
    }

    public bool TryAdd(Item item, int qty = 1)
    {
        if (item.isStackable)
            foreach (var s in Slots)
                if (s.CanAccept(item))
                {
                    int take = Mathf.Min(qty, item.maxStack - s.quantity);
                    s.quantity += take; qty -= take;
                    if (qty == 0) { OnChanged?.Invoke(); return true; }
                }
        foreach (var s in Slots)
            if (s.IsEmpty) { s.Item = item; s.quantity = qty; OnChanged?.Invoke(); return true; }
        return false;
    }

    public void RemoveAt(int index, int qty = 1)
    {
        var s = Slots[index];
        if (s.IsEmpty) return;
        s.quantity -= qty;
        if (s.quantity <= 0) { s.Item = null; s.quantity = 0; }
        OnChanged?.Invoke();
    }

    // Move/swap items between two slots. Stacks onto same item type when possible.
    public void Move(int from, int to)
    {
        if (from < 0 || to < 0 || from >= Slots.Count || to >= Slots.Count || from == to) return;
        var a = Slots[from];
        var b = Slots[to];
        if (a.IsEmpty) return;

        if (!b.IsEmpty && a.Item != null && b.Item.ID == a.Item.ID && b.quantity < b.Item.maxStack)
        {
            int take = Mathf.Min(a.quantity, b.Item.maxStack - b.quantity);
            b.quantity += take;
            a.quantity -= take;
            if (a.quantity <= 0) { a.Item = null; a.quantity = 0; }
        }
        else
        {
            Slots[from] = b;
            Slots[to] = a;
        }
        OnChanged?.Invoke();
    }
}
