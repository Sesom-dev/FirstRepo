using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;

public class SettingsUI : MonoBehaviour
{
    public KeyCode toggleKey = KeyCode.Tab;

    private GameObject panel;
    private Image vignette;
    private bool isOpen;

    void Awake()
    {
        var canvas = GameObject.Find("Canvas");
        if (canvas == null)
        {
            canvas = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvas.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        }
        if (FindObjectOfType<EventSystem>() == null)
            new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

        BuildUI(canvas.transform);
        panel.SetActive(false);
    }

    void BuildUI(Transform parent)
    {
        // Vignette: always visible in-game, direct Canvas child (below the panel)
        var vigGO = new GameObject("Vignette", typeof(RectTransform), typeof(Image));
        vigGO.transform.SetParent(parent, false);
        var vrt = (RectTransform)vigGO.transform;
        vrt.anchorMin = Vector2.zero; vrt.anchorMax = Vector2.one; vrt.offsetMin = Vector2.zero; vrt.offsetMax = Vector2.zero;
        vignette = vigGO.GetComponent<Image>();
        vignette.sprite = Sprite.Create(CreateRadialTexture(), new Rect(0, 0, 256, 256), Vector2.one * 0.5f);
        vignette.raycastTarget = false;
        SetVignetteAlpha(0.4f);

        // Full-screen overlay (covers everything, including inventory)
        panel = new GameObject("SettingsPanel", typeof(RectTransform), typeof(Image));
        panel.transform.SetParent(parent, false);
        var rt = (RectTransform)panel.transform;
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        var bg = panel.GetComponent<Image>();
        bg.color = new Color(0f, 0f, 0f, 0.7f);
        bg.raycastTarget = true;

        // Centered controls container
        var container = new GameObject("Controls", typeof(RectTransform), typeof(VerticalLayoutGroup));
        container.transform.SetParent(panel.transform, false);
        var crt = (RectTransform)container.transform;
        crt.anchorMin = new Vector2(0.5f, 0.5f); crt.anchorMax = new Vector2(0.5f, 0.5f);
        crt.sizeDelta = new Vector2(360f, 300f);
        var vlg = container.GetComponent<VerticalLayoutGroup>();
        vlg.childAlignment = TextAnchor.MiddleCenter;
        vlg.spacing = 20f; vlg.childForceExpandHeight = false; vlg.childForceExpandWidth = true;

        // Title
        AddLabel(container.transform, "SETTINGS", 32, FontStyles.Bold);

        // Vignette label + slider
        AddLabel(container.transform, "Vignette", 20, FontStyles.Normal);
        var slider = AddSlider(container.transform, 0.4f);
        slider.onValueChanged.AddListener(SetVignetteAlpha);

        // Leave Game button (display only)
        var leaveBtn = AddButton(container.transform, "Leave Game", new Color(0.8f, 0.15f, 0.15f, 1f));
        leaveBtn.onClick.AddListener(() => Debug.Log("[SettingsUI] Leave Game clicked (not implemented)"));
    }

    void SetVignetteAlpha(float a)
    {
        if (vignette) { var c = vignette.color; c.a = a; vignette.color = c; }
    }

    void Update()
    {
        if (Input.GetKeyDown(toggleKey)) Toggle();
    }

    void Toggle()
    {
        isOpen = !isOpen;
        panel.SetActive(isOpen);
        Time.timeScale = isOpen ? 0f : 1f;
        Cursor.lockState = isOpen ? CursorLockMode.None : CursorLockMode.Locked;
        Cursor.visible = isOpen;
    }

    void OnDestroy()
    {
        // Safety: never leave the game paused or cursor locked if this object is destroyed while open
        if (isOpen) { Time.timeScale = 1f; Cursor.lockState = CursorLockMode.Locked; Cursor.visible = false; }
    }

    // --- UI builders ---
    TMP_Text AddLabel(Transform parent, string text, int size, FontStyles style)
    {
        var go = new GameObject("Label", typeof(RectTransform), typeof(TextMeshProUGUI));
        go.transform.SetParent(parent, false);
        var t = go.GetComponent<TextMeshProUGUI>();
        t.text = text; t.fontSize = size; t.fontStyle = style; t.alignment = TextAlignmentOptions.Center;
        t.color = Color.white;
        return t;
    }

    Slider AddSlider(Transform parent, float value)
    {
        var go = new GameObject("Slider", typeof(RectTransform), typeof(Slider), typeof(Image));
        go.transform.SetParent(parent, false);
        var irt = (RectTransform)go.transform;
        irt.sizeDelta = new Vector2(300f, 30f);
        var slider = go.GetComponent<Slider>();
        var bg = go.GetComponent<Image>();
        bg.color = new Color(0.2f, 0.2f, 0.2f, 1f);
        slider.fillRect = MakeSliderChild("Fill", new Color(0.4f, 0.7f, 1f, 1f), go.transform);
        slider.handleRect = MakeSliderChild("Handle", Color.white, go.transform);
        slider.targetGraphic = bg;
        slider.minValue = 0f; slider.maxValue = 1f; slider.value = value;
        return slider;
    }

    RectTransform MakeSliderChild(string name, Color color, Transform parent)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        go.GetComponent<Image>().color = color;
        var r = (RectTransform)go.transform;
        r.anchorMin = Vector2.zero; r.anchorMax = Vector2.one;
        return r;
    }

    Button AddButton(Transform parent, string label, Color bgColor)
    {
        var go = new GameObject("Button", typeof(RectTransform), typeof(Image), typeof(Button));
        go.transform.SetParent(parent, false);
        var brt = (RectTransform)go.transform;
        brt.sizeDelta = new Vector2(220f, 50f);
        var img = go.GetComponent<Image>(); img.color = bgColor;
        var btn = go.GetComponent<Button>();
        var t = AddLabel(go.transform, label, 22, FontStyles.Bold);
        t.rectTransform.anchorMin = Vector2.zero; t.rectTransform.anchorMax = Vector2.one;
        t.rectTransform.offsetMin = Vector2.zero; t.rectTransform.offsetMax = Vector2.zero;
        return btn;
    }

    // --- radial gradient texture for vignette ---
    Texture2D CreateRadialTexture(int size = 256)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
        var pixels = new Color[size * size];
        float half = size * 0.5f;
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                float d = Vector2.Distance(new Vector2(x, y), Vector2.one * half) / half;
                float a = Mathf.Clamp01((d - 0.3f) / 0.7f); // transparent center, black edges
                pixels[y * size + x] = new Color(0f, 0f, 0f, a);
            }
        tex.SetPixels(pixels); tex.Apply();
        return tex;
    }
}
